# Licence d'utilisation de Desktroo

Version 1.3 du 24 octobre 2026

**© 2026 Mdm-services.fr. Tous droits réservés.**

Desktroo est un logiciel propriétaire. Son code est lisible parce qu'il s'installe sur votre NAS, pas parce qu'il est libre : aucune licence open source ne s'applique à Desktroo.

En installant ou en utilisant Desktroo, vous acceptez la présente licence. Si vous ne l'acceptez pas, n'installez pas le logiciel et ne l'utilisez pas.

*An English translation follows the French text. The French text prevails.*

## 1. Définitions

- **Le Logiciel** : Desktroo, le bureau web pour TrueNAS, dans toutes ses versions. Il comprend la page du bureau, le service qui l'accompagne, l'assistant et les scripts d'installation et de mise à jour, l'extension de navigateur, l'extension WordPress, la documentation, ainsi que le nom « Desktroo », son logo et ses éléments graphiques.
- **L'Éditeur** : Mdm-services.fr, titulaire des droits sur le Logiciel.
- **Vous** : la personne ou l'organisation qui installe ou utilise le Logiciel.

## 2. Ce que la licence vous permet

L'Éditeur vous accorde un droit personnel, non exclusif et non cessible :

- d'installer le Logiciel sur les serveurs TrueNAS dont vous avez l'usage légitime ;
- de l'utiliser gratuitement pour vos propres besoins, sans limite de durée, aux conditions publiées sur https://desktroo.fr ;
- d'en faire les copies de sauvegarde nécessaires à cet usage ;
- de créer des fichiers de langue pour le Logiciel (dossier `lang/` de l'installation, ajoutés depuis le bureau), de les utiliser et de les partager librement. Un fichier de langue contient les textes de l'interface et leur traduction, et aucun code du Logiciel. Si vous en transmettez un à l'Éditeur, vous l'autorisez à le reprendre gratuitement dans Desktroo.

Tout ce qui n'est pas expressément permis ici est réservé à l'Éditeur.

## 3. Ce qui est interdit

Sans l'accord écrit et préalable de l'Éditeur, vous ne pouvez pas :

1. copier, publier, distribuer, mettre à disposition, vendre, louer ou concéder en sous-licence tout ou partie du Logiciel, modifié ou non ;
2. modifier, adapter, traduire ou transformer le Logiciel (hors fichiers de langue, permis à l'article 2), ni en tirer un autre logiciel, y compris en confiant son code à un outil d'intelligence artificielle pour le réécrire, le traduire dans un autre langage ou en produire une variante ;
3. retirer, masquer ou modifier les mentions de droits, de titulaire, de marque ou de licence présentes dans le Logiciel ;
4. présenter le Logiciel, ou un logiciel qui en est tiré, comme votre œuvre ou celle d'un tiers ;
5. contourner, désactiver ou altérer le contrôle de licence ou tout autre dispositif de protection ;
6. utiliser le nom « Desktroo », son logo ou ses éléments graphiques pour désigner un autre produit ou service, ou d'une façon qui laisse croire à un lien avec l'Éditeur.

## 4. Droits que la loi vous réserve

Rien dans cette licence ne limite les droits que la loi accorde à l'utilisateur légitime d'un logiciel et auxquels il n'est pas possible de déroger, notamment ceux de l'article L. 122-6-1 du Code de la propriété intellectuelle, ni les droits des consommateurs.

## 5. Propriété

Le Logiciel vous est concédé en licence ; il ne vous est pas vendu. L'Éditeur reste titulaire de tous les droits sur le Logiciel, ses copies et ses mises à jour.

Vos données restent les vôtres : les fichiers, les réglages et tout ce que contient votre NAS ne sont pas concernés par cette licence.

Les idées, remarques et signalements que vous envoyez à l'Éditeur peuvent être utilisés librement par lui pour améliorer le Logiciel.

## 6. Composants et produits tiers

Cette licence ne s'applique pas aux éléments suivants, qui restent soumis à leurs propres licences :

- les polices Figtree, Schibsted Grotesk et JetBrains Mono, embarquées dans le Logiciel, sous licence SIL Open Font License 1.1 ;
- noVNC (Mozilla Public License 2.0) et CodeMirror (licence MIT), chargés par le navigateur quand vous ouvrez la console d'une machine virtuelle ou l'éditeur de texte ;
- les logiciels que Desktroo pilote ou installe sur votre NAS : TrueNAS, Docker, les applications du catalogue, les sites web et leurs bases de données.

TrueNAS est une marque d'iXsystems, Inc. Desktroo est un produit indépendant : il n'est ni édité ni approuvé par iXsystems.

## 7. Durée et fin de la licence

La licence prend effet dès l'installation.

Le Logiciel est fourni gratuitement et sans limite de durée, et il est utilisable sans clé d'activation. La clé d'activation, délivrée gratuitement sur simple demande, donne accès : aux mises à jour publiées par l'Éditeur ; au programme de test (versions bêta du Logiciel et applications en test) ; à l'installation des applications du magasin Desktroo Apps et à leurs mises à jour ; à l'envoi de signalements et de demandes de fonctionnalités depuis le Logiciel. Sans clé, les applications déjà installées restent utilisables dans leur version, et les correctifs de sécurité, du Logiciel comme de ces applications, restent accessibles. La clé permet aussi à l'Éditeur de connaître le nombre d'installations en service.

La licence prend fin de plein droit si vous ne respectez pas l'article 3. Vous devez alors cesser d'utiliser le Logiciel et en supprimer toutes les copies.

## 8. Garantie et responsabilité

Desktroo donne un contrôle étendu sur votre NAS. Il vous appartient de sauvegarder vos données et de vérifier que le Logiciel convient à votre usage.

Dans les limites permises par la loi, le Logiciel est fourni en l'état, sans garantie d'aucune sorte, et l'Éditeur n'est pas responsable des pertes de données, des interruptions de service ni des dommages indirects liés à son utilisation.

Ces limites ne s'appliquent pas en cas de faute lourde ou intentionnelle de l'Éditeur, ni aux garanties légales dont bénéficient les consommateurs.

## 9. Droit applicable

Cette licence est soumise au droit français. Sous réserve des règles qui protègent les consommateurs, tout litige relève des tribunaux français compétents.

## 10. Contact

Pour demander une autorisation, signaler une copie ou poser une question sur cette licence : https://desktroo.fr, ou « Signaler un problème » dans la fenêtre « À propos » de Desktroo.

---

# Desktroo licence agreement

Version 1.3, 24 October 2026

**© 2026 Mdm-services.fr. All rights reserved.**

*This is a translation provided for convenience. If the two texts differ, the French text above prevails.*

Desktroo is proprietary software. Its code is readable because it is installed on your NAS, not because it is free software: no open-source licence applies to Desktroo.

By installing or using Desktroo, you accept this licence. If you do not accept it, do not install or use the software.

## 1. Definitions

- **The Software**: Desktroo, the web desktop for TrueNAS, in all its versions. It includes the desktop page, the service that comes with it, the installation and update wizard and scripts, the browser extension, the WordPress plugin, the documentation, and the name “Desktroo”, its logo and its graphic elements.
- **The Publisher**: Mdm-services.fr, owner of the rights in the Software.
- **You**: the person or organisation that installs or uses the Software.

## 2. What the licence allows

The Publisher grants you a personal, non-exclusive, non-transferable right to:

- install the Software on the TrueNAS servers you are legitimately entitled to use;
- use it for your own needs, free of charge and with no time limit, under the terms published at https://desktroo.fr;
- make the backup copies needed for that use;
- create language files for the Software (the `lang/` folder of the installation, added from the desktop), use them and share them freely. A language file contains the interface texts and their translation, and no code of the Software. If you send one to the Publisher, you allow the Publisher to include it in Desktroo free of charge.

Everything not expressly allowed here is reserved to the Publisher.

## 3. What is forbidden

Without the Publisher's prior written consent, you may not:

1. copy, publish, distribute, make available, sell, rent or sublicense all or part of the Software, modified or not;
2. modify, adapt, translate or transform the Software (except language files, allowed in section 2), or derive other software from it, including by giving its code to an artificial intelligence tool to rewrite it, port it to another language or produce a variant;
3. remove, hide or alter the copyright, ownership, trademark or licence notices in the Software;
4. present the Software, or software derived from it, as your own work or someone else's;
5. bypass, disable or tamper with the licence check or any other protection;
6. use the name “Desktroo”, its logo or its graphic elements to designate another product or service, or in a way that suggests a link with the Publisher.

## 4. Rights reserved to you by law

Nothing in this licence limits the rights the law grants to the lawful user of software and that cannot be waived, in particular those of article L. 122-6-1 of the French Intellectual Property Code, or consumer rights.

## 5. Ownership

The Software is licensed to you, not sold. The Publisher remains the owner of all rights in the Software, its copies and its updates.

Your data remains yours: the files, settings and everything stored on your NAS are not covered by this licence.

The ideas, comments and reports you send to the Publisher may be used freely by the Publisher to improve the Software.

## 6. Third-party components and products

This licence does not apply to the following, which remain under their own licences:

- the Figtree, Schibsted Grotesk and JetBrains Mono fonts embedded in the Software, under the SIL Open Font License 1.1;
- noVNC (Mozilla Public License 2.0) and CodeMirror (MIT licence), loaded by the browser when you open a virtual machine console or the text editor;
- the software Desktroo controls or installs on your NAS: TrueNAS, Docker, catalogue applications, websites and their databases.

TrueNAS is a trademark of iXsystems, Inc. Desktroo is an independent product: it is neither published nor endorsed by iXsystems.

## 7. Term and termination

The licence takes effect on installation.

The Software is provided free of charge and with no time limit, and it can be used without an activation key. The activation key, issued free of charge on request, gives access to: the updates published by the Publisher; the test programme (beta versions of the Software and apps in testing); installing apps from the Desktroo Apps store and their updates; sending bug reports and feature requests from the Software. Without a key, apps already installed remain usable in their current version, and security fixes, for the Software and for these apps, remain available. The key also lets the Publisher know how many installations are running.

The licence ends automatically if you do not comply with section 3. You must then stop using the Software and delete all copies of it.

## 8. Warranty and liability

Desktroo gives extensive control over your NAS. You are responsible for backing up your data and for checking that the Software suits your use.

To the extent permitted by law, the Software is provided as is, without warranty of any kind, and the Publisher is not liable for data loss, service interruptions or indirect damage related to its use.

These limits do not apply in the event of gross or intentional misconduct by the Publisher, nor to the statutory warranties consumers are entitled to.

## 9. Governing law

This licence is governed by French law. Subject to the rules protecting consumers, any dispute falls under the jurisdiction of the competent French courts.

## 10. Contact

To request permission, report a copy or ask a question about this licence: https://desktroo.fr, or “Report a problem” in Desktroo's “About” window.
