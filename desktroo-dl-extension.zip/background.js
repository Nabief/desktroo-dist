/* Desktroo, extension de téléchargements : service d'arrière-plan.
   Il porte les entrées du clic droit, envoie les liens au NAS et tient à jour le compteur de l'icône.
   Tous les appels au NAS partent d'ici ou des pages de l'extension, jamais d'une page web. */
'use strict';
if (typeof DK === 'undefined' && typeof importScripts === 'function') importScripts('lib.js');

var M_LINK = 'dk-send-link', M_PAGE = 'dk-pick-page';
function ensureMenus() {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({ id: M_LINK, title: DK.t('menuSendLink'), contexts: ['link'] });
    chrome.contextMenus.create({ id: M_PAGE, title: DK.t('menuPickPage'), contexts: ['page', 'selection'] });
  });
}

function notify(message) {
  try { chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon-128.png', title: 'Desktroo', message: String(message) }); } catch (e) {}
}

// Compteur de l'icône : téléchargements en cours ou en attente.
async function updateBadge() {
  var text = '';
  try {
    var res = await DK.call('/downloads/list');
    if (res.ok) { var n = (res.data.downloads || []).filter(DK.isActive).length; text = n ? String(n) : ''; }
    var c = await DK.cfg(), p = DK.palette(c.accent).d;
    chrome.action.setBadgeBackgroundColor({ color: p[0] });
    if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: p[2] });
  } catch (e) {}
  try { chrome.action.setBadgeText({ text: text }); } catch (e) {}
}

// Envoi d'un ou plusieurs liens. Rend le résultat de DK.call, complété du nombre de liens pris.
async function sendUrls(urls) {
  var c = await DK.cfg();
  var payload = { urls: urls, premium: c.premium || 'auto' };
  if (c.connections) payload.connections = Number(c.connections);
  if (c.dir) payload.dir = c.dir;
  var res = await DK.call('/downloads/add-batch', payload, c);
  if (res.ok) {
    res.added = res.data.added || 0; res.failed = res.data.failed || 0;
    res.reason = ((res.data.results || []).find(function (x) { return !x.ok && x.error; }) || {}).error || '';
    updateBadge();
  }
  res.text = sentText(res, c);
  return res;
}
function sentText(res, c) {
  if (!res.ok) return DK.explain(res, c);
  if (!res.added) return DK.t('sentNone', res.reason || '');
  var s = res.added > 1 ? DK.t('sentMany', res.added) : DK.t('sentOne');
  return res.failed ? s + ' ' + (res.failed > 1 ? DK.t('sentFailedMany', res.failed) : DK.t('sentFailedOne')) : s;
}
async function sendAndNotify(urls) {
  var res = await sendUrls(urls);
  notify(res.text);
  // Rien n'est réglé, ou le navigateur n'a pas encore autorisé l'adresse du NAS : les réglages s'ouvrent.
  if (!res.ok && (res.kind === 'setup' || res.kind === 'perm' || res.kind === 'token')) chrome.runtime.openOptionsPage();
  if (!res.ok && res.kind === 'auth' && res.login) { try { chrome.tabs.create({ url: res.login }); } catch (e) {} }
}

chrome.runtime.onInstalled.addListener(function () { ensureMenus(); updateBadge(); });
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(function () { ensureMenus(); updateBadge(); });
chrome.alarms.create('dk-badge', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'dk-badge') updateBadge(); });
chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && (ch.url || ch.token || ch.accent)) updateBadge(); });
if (chrome.permissions && chrome.permissions.onAdded) chrome.permissions.onAdded.addListener(updateBadge);
if (chrome.permissions && chrome.permissions.onRemoved) chrome.permissions.onRemoved.addListener(updateBadge);

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === M_LINK && info.linkUrl) { sendAndNotify([info.linkUrl]); return; }
  if (info.menuItemId === M_PAGE && tab && tab.id != null) {
    // Le clic droit vaut autorisation pour cet onglet seulement (activeTab) : on y pose le sélecteur de liens.
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['picker.js'] }).catch(function () { notify(DK.t('errPickPage')); });
  }
});

// Demandes venues du sélecteur de liens (dans une page) ou de la fenêtre de l'icône.
chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg || sender.id !== chrome.runtime.id) return;
  if (msg.type === 'dk-send' && Array.isArray(msg.urls)) {
    sendUrls(msg.urls.map(String).filter(function (u) { return /^https?:\/\//i.test(u); }).slice(0, 500)).then(reply);
    return true;   // réponse différée
  }
  if (msg.type === 'dk-badge') { updateBadge(); return; }
  if (msg.type === 'dk-options') { chrome.runtime.openOptionsPage(); return; }
});
