/* Desktroo, extension de téléchargements : ce que partagent le service d'arrière-plan, la fenêtre de l'icône
   et la page de réglages. Chargé par <script> dans les pages, par importScripts dans le service worker. */
'use strict';
var DK = (function () {
  var KEYS = ['url', 'token', 'premium', 'connections', 'dir', 'accent', 'pending'];

  // Texte dans la langue du navigateur (français par défaut, anglais fourni).
  function t(key) {
    var subs = Array.prototype.slice.call(arguments, 1).map(String);
    var m = '';
    try { m = chrome.i18n.getMessage(key, subs); } catch (e) {}
    return m || key;
  }

  // Réglages. Tout reste sur ce poste (storage.local) : le jeton ouvre les fichiers du NAS, il ne doit pas
  // partir sur le compte du navigateur. Les versions 1.x le rangeaient dans storage.sync : on le rapatrie.
  var migrated = null;
  function migrate() {
    if (migrated) return migrated;
    migrated = (async function () {
      try {
        var old = await chrome.storage.sync.get(['url', 'token', 'premium', 'connections', 'dir']);
        if (!old || (!old.url && !old.token && !old.premium && !old.connections && !old.dir)) return;
        var cur = await chrome.storage.local.get(['url', 'token']);
        if (!cur.url && !cur.token) await chrome.storage.local.set(old);
        await chrome.storage.sync.remove(['url', 'token', 'premium', 'connections', 'dir']);
      } catch (e) {}
    })();
    return migrated;
  }
  async function cfg() {
    await migrate();
    var c = await chrome.storage.local.get(KEYS);
    c.url = String(c.url || '').replace(/\/+$/, '');
    c.token = String(c.token || '');
    return c;
  }
  function save(patch) { return chrome.storage.local.set(patch); }
  function forget(keys) { return chrome.storage.local.remove(keys); }

  function origin(url) { try { return new URL(url).origin; } catch (e) { return ''; } }
  function host(url) { try { return new URL(url).host; } catch (e) { return ''; } }
  // Motif d'autorisation : l'hôte du NAS, sans le port (Firefox ne l'accepte pas dans un motif).
  function pattern(url) { try { var u = new URL(url); return /^https?:$/.test(u.protocol) ? u.protocol + '//' + u.hostname + '/*' : ''; } catch (e) { return ''; } }
  // « https://nas.exemple.fr » ou « …/fileops » → adresse du service, toujours terminée par /fileops.
  function serviceUrl(input) {
    var s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    var o = origin(s);
    return o ? o + '/fileops' : '';
  }
  // L'extension n'a le droit de joindre que le NAS qu'on lui a désigné.
  async function allowed(url) {
    var p = pattern(url);
    if (!p) return false;
    try { return await chrome.permissions.contains({ origins: [p] }); } catch (e) { return false; }
  }

  // Code de connexion copié depuis Desktroo : « desktroo:<base64 de {u,t}> ».
  function parseCode(text) {
    var m = /desktroo:([A-Za-z0-9_\-+/=]+)/.exec(String(text || '').trim());
    if (!m) return null;
    try {
      var j = JSON.parse(decodeURIComponent(escape(atob(m[1].replace(/-/g, '+').replace(/_/g, '/')))));
      var u = serviceUrl(j.u);
      return u && j.t ? { url: u, token: String(j.t) } : null;
    } catch (e) { return null; }
  }

  // Appel au service Desktroo. Rend toujours un objet : { ok, data } ou { ok:false, kind, message }.
  //   setup   : rien n'est réglé          perm  : le navigateur n'a pas autorisé cette adresse
  //   network : NAS injoignable           auth  : le portail d'authentification a répondu à la place du service
  //   token   : jeton refusé              api   : le service a répondu par une erreur
  async function call(path, body, conf) {
    var c = conf || await cfg();
    if (!c.url || !c.token) return { ok: false, kind: 'setup' };
    if (!(await allowed(c.url))) return { ok: false, kind: 'perm' };
    var r;
    try {
      r = await fetch(c.url + path, {
        method: body ? 'POST' : 'GET', credentials: 'include', cache: 'no-store',
        headers: Object.assign({ 'X-Fileops-Token': c.token }, body ? { 'Content-Type': 'application/json' } : {}),
        body: body ? JSON.stringify(body) : undefined
      });
    } catch (e) { return { ok: false, kind: 'network', message: String((e && e.message) || e) }; }
    var ct = (r.headers.get('content-type') || '').toLowerCase();
    if (r.redirected || ct.indexOf('json') < 0) return { ok: false, kind: 'auth', login: (r.redirected && r.url) || (origin(c.url) + '/') };
    var j = null;
    try { j = await r.json(); } catch (e) { return { ok: false, kind: 'auth', login: origin(c.url) + '/' }; }
    if (r.status === 401 || r.status === 403) return { ok: false, kind: 'token' };
    if (!r.ok || (j && j.error)) return { ok: false, kind: 'api', message: String((j && j.error) || ('HTTP ' + r.status)) };
    return { ok: true, data: j || {} };
  }
  // Phrase à montrer pour un échec.
  function explain(res, conf) {
    var h = host((conf && conf.url) || '');
    if (res.kind === 'setup') return t('errSetup');
    if (res.kind === 'perm') return t('errPerm', h);
    if (res.kind === 'network') return t('errNetwork', h);
    if (res.kind === 'auth') return t('errAuth');
    if (res.kind === 'token') return t('errToken');
    return res.message ? t('errApi', res.message) : t('errUnknown');
  }

  // ── Couleur du thème : celle de l'installation Desktroo, lue sur le NAS ──
  var PALETTES = {
    green:  { d: ['#3ecf8e', '#55dca0', '#04231a'], l: ['#0a8451', '#0a8451', '#ffffff'] },
    blue:   { d: ['#4d9fff', '#7fbaff', '#031a36'], l: ['#1766d6', '#1766d6', '#ffffff'] },
    red:    { d: ['#f25f66', '#ff8a8f', '#2e0508'], l: ['#c9303a', '#c9303a', '#ffffff'] },
    amber:  { d: ['#f5a524', '#ffc05c', '#2b1a00'], l: ['#a66300', '#a66300', '#ffffff'] },
    yellow: { d: ['#f0d43a', '#f7e277', '#2a2400'], l: ['#e3c019', '#7a6400', '#2a2400'] },
    gray:   { d: ['#aab5c8', '#c8d0de', '#0f1520'], l: ['#4b5768', '#4b5768', '#ffffff'] }
  };
  function rgbOf(hex) { var n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  // Couleur libre : même calcul que dans Desktroo (éclaircie en sombre, assombrie en clair, pour rester lisible).
  function customPalette(hex) {
    var c = rgbOf(hex), r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn, s = d ? d / (1 - Math.abs(2 * l - 1)) : 0, h = 0;
    if (d) { h = 60 * (mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4); if (h < 0) h += 360; }
    var rgb = function (li) {
      var cc = (1 - Math.abs(2 * li - 1)) * s, x = cc * (1 - Math.abs(h / 60 % 2 - 1)), m = li - cc / 2;
      var tt = h < 60 ? [cc, x, 0] : h < 120 ? [x, cc, 0] : h < 180 ? [0, cc, x] : h < 240 ? [0, x, cc] : h < 300 ? [x, 0, cc] : [cc, 0, x];
      return tt.map(function (v) { return Math.max(0, Math.min(255, Math.round((v + m) * 255))); });
    };
    var lum = function (cc) { return (0.299 * cc[0] + 0.587 * cc[1] + 0.114 * cc[2]) / 255; };
    var hx = function (cc) { return '#' + cc.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); };
    var dl = Math.max(0.5, Math.min(0.8, l)), ll = Math.min(0.5, l);
    while (lum(rgb(dl)) < 0.5 && dl < 0.86) dl += 0.02;
    while (lum(rgb(ll)) > 0.4 && ll > 0.1) ll -= 0.02;
    return { d: [hx(rgb(dl)), hx(rgb(Math.min(0.9, dl + 0.09))), hx(rgb(0.08))], l: [hx(rgb(ll)), hx(rgb(ll)), '#ffffff'] };
  }
  function palette(accent) {
    var a = String(accent || 'green').toLowerCase();
    if (/^#[0-9a-f]{6}$/.test(a)) return customPalette(a);
    return PALETTES[a] || PALETTES.green;
  }
  // Pose la couleur sur une page de l'extension (fenêtre de l'icône, réglages).
  function paint(accent) {
    if (typeof document === 'undefined') return;
    var p = palette(accent), light = window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches, v = light ? p.l : p.d;
    var s = document.documentElement.style;
    s.setProperty('--accent', v[0]); s.setProperty('--accent-rgb', rgbOf(v[0]).join(','));
    s.setProperty('--accent2', v[1]); s.setProperty('--accent-ink', v[2]);
    s.setProperty('--brand', p.d[0]);
  }
  // Relit la couleur de l'installation (sans bloquer : la dernière connue est déjà appliquée).
  async function refreshAccent(conf) {
    var res = await call('/branding', null, conf);
    var a = res.ok && res.data && typeof res.data.accent === 'string' ? res.data.accent.toLowerCase() : '';
    if (!a || (!PALETTES[a] && !/^#[0-9a-f]{6}$/.test(a))) return null;
    await save({ accent: a });
    return a;
  }

  // Remplit les textes d'une page : data-i18n (texte), data-i18n-title, data-i18n-placeholder, data-i18n-aria.
  function localize(root) {
    root = root || document;
    root.querySelectorAll('[data-i18n]').forEach(function (e) { e.textContent = t(e.getAttribute('data-i18n')); });
    root.querySelectorAll('[data-i18n-title]').forEach(function (e) { e.title = t(e.getAttribute('data-i18n-title')); });
    root.querySelectorAll('[data-i18n-placeholder]').forEach(function (e) { e.placeholder = t(e.getAttribute('data-i18n-placeholder')); });
    root.querySelectorAll('[data-i18n-aria]').forEach(function (e) { e.setAttribute('aria-label', t(e.getAttribute('data-i18n-aria'))); });
    try { document.documentElement.lang = chrome.i18n.getUILanguage().slice(0, 2); } catch (e) {}
  }

  var ACTIVE = { downloading: 1, queued: 1, extracting: 1 };
  return { t: t, cfg: cfg, save: save, forget: forget, origin: origin, host: host, pattern: pattern, serviceUrl: serviceUrl, allowed: allowed,
    parseCode: parseCode, call: call, explain: explain, palette: palette, paint: paint, refreshAccent: refreshAccent, localize: localize,
    isActive: function (d) { return !!ACTIVE[d && d.status]; } };
})();
