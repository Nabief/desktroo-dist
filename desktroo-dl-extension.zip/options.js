/* Desktroo — © 2026 Mdm-services.fr. Tous droits réservés.
   Logiciel propriétaire, soumis à la licence d'utilisation de Desktroo (LICENSE.md, https://desktroo.fr).
   Copie, modification et redistribution interdites sans accord écrit. Cette mention ne doit pas être retirée. */
/* Desktroo, extension de téléchargements : page de réglages.
   C'est ici que le navigateur demande l'autorisation de joindre le NAS : la demande doit partir d'un clic,
   sans attente avant elle, d'où les réglages lus d'avance et gardés dans CONF. */
'use strict';
var $ = function (id) { return document.getElementById(id); };
var t = DK.t, CONF = {}, busy = false;

function msg(text, kind) { var m = $('link-msg'); m.hidden = !text; m.className = 'msg' + (kind ? ' ' + kind : ''); m.textContent = text || ''; }
function linkState(dot, text, bad) {
  $('l-dot').className = 'dot' + (dot ? ' ' + dot : '');
  $('l-state').className = bad ? 'bad' : ''; $('l-state').textContent = text;
}

// Affiche la bonne carte : relié, Desktroo repéré à autoriser, ou rien.
function show() {
  var linked = !!(CONF.url && CONF.token), pend = !linked && CONF.pending && CONF.pending.url && CONF.pending.token;
  $('linked').hidden = !linked; $('pending').hidden = !pend; $('unlinked').hidden = linked || !!pend;
  if (linked) $('l-host').textContent = DK.host(CONF.url);
  if (pend) $('p-host').textContent = t('pendingTitle', DK.host(CONF.pending.url));
}

// Demande au navigateur le droit de joindre cette adresse, puis enregistre la liaison.
// À appeler directement depuis un clic : aucune attente avant chrome.permissions.request.
function link(url, token) {
  var pat = DK.pattern(url);
  if (!pat || !token) { msg(t('manualBad'), 'bad'); return; }
  if (busy) return;
  busy = true; msg('');
  var done = function (granted) {
    busy = false;
    if (!granted) { msg(t('permDenied', DK.host(url)), 'bad'); return; }
    var old = CONF.url && DK.pattern(CONF.url) !== pat ? DK.pattern(CONF.url) : '';
    CONF.url = url; CONF.token = token; CONF.pending = null;
    $('code').value = ''; $('m-url').value = ''; $('m-token').value = '';
    show(); linkState('', t('stChecking'));
    DK.save({ url: url, token: token }).then(function () { return DK.forget(['pending']); }).then(function () {
      if (old) { try { chrome.permissions.remove({ origins: [old] }); } catch (e) {} }
      test();
    });
  };
  try { chrome.permissions.request({ origins: [pat] }, function (g) { done(!chrome.runtime.lastError && !!g); }); }
  catch (e) { done(false); }
}

// Vérifie la liaison et dit en clair ce qui manque.
var testing = false;
async function test() {
  if (!CONF.url || !CONF.token || testing) return;
  testing = true;
  try { await check(); } finally { testing = false; }
}
async function check() {
  var h = DK.host(CONF.url);
  $('l-allow').hidden = true; $('l-login').hidden = true;
  linkState('', t('stChecking'));
  var res = await DK.call('/downloads/list', null, CONF);
  if (res.ok) {
    var n = (res.data.downloads || []).filter(DK.isActive).length;
    linkState('ok', n > 1 ? t('stOkMany', n) : n === 1 ? t('stOkOne') : t('stOk'));
    DK.refreshAccent(CONF).then(function (a) { if (a) DK.paint(a); });
    try { chrome.runtime.sendMessage({ type: 'dk-badge' }); } catch (e) {}
    return;
  }
  if (res.kind === 'perm') { $('l-allow').hidden = false; $('l-allow').textContent = t('allowHost', h); linkState('warn', t('errPerm', h)); }
  else if (res.kind === 'auth') { $('l-login').hidden = false; $('l-login').dataset.url = res.login || DK.origin(CONF.url) + '/'; linkState('warn', t('errAuth')); }
  else linkState('bad', DK.explain(res, CONF), true);
}

function unlink() {
  var pat = DK.pattern(CONF.url), h = DK.host(CONF.url);
  DK.forget(['url', 'token', 'accent', 'pending']).then(function () {
    var after = function () { CONF.url = ''; CONF.token = ''; CONF.pending = null; show(); msg(t('unlinkDone', h), 'ok'); DK.paint(''); };
    try { chrome.permissions.remove({ origins: [pat] }, after); } catch (e) { after(); }
  });
}

// Préférences d'envoi : enregistrées dès qu'on les change.
var savedTimer = null;
function savePrefs() {
  var c = $('connections').value;
  var patch = { premium: $('premium').value, dir: $('dir').value.trim() };
  var go = c ? DK.save(Object.assign(patch, { connections: Number(c) })) : DK.save(patch).then(function () { return DK.forget(['connections']); });
  go.then(function () {
    $('saved').classList.add('on');
    clearTimeout(savedTimer); savedTimer = setTimeout(function () { $('saved').classList.remove('on'); }, 1800);
  });
}

$('p-go').addEventListener('click', function () { if (CONF.pending) link(CONF.pending.url, CONF.pending.token); });
$('p-skip').addEventListener('click', function () { DK.forget(['pending']); CONF.pending = null; show(); });
$('code-form').addEventListener('submit', function (e) {
  e.preventDefault();
  var c = DK.parseCode($('code').value);
  if (!c) { msg(t('codeBad'), 'bad'); return; }
  link(c.url, c.token);
});
$('manual-form').addEventListener('submit', function (e) {
  e.preventDefault();
  link(DK.serviceUrl($('m-url').value), $('m-token').value.trim());
});
$('l-allow').addEventListener('click', function () { link(CONF.url, CONF.token); });
$('l-login').addEventListener('click', function () { chrome.tabs.create({ url: $('l-login').dataset.url }); });
$('l-test').addEventListener('click', test);
$('l-open').addEventListener('click', function () { chrome.tabs.create({ url: DK.origin(CONF.url) + '/?app=downloads' }); });
$('l-unlink').addEventListener('click', unlink);
['premium', 'connections'].forEach(function (id) { $(id).addEventListener('change', savePrefs); });
$('dir').addEventListener('change', savePrefs);

// Réglages changés ailleurs (la fenêtre de l'icône vient de repérer un Desktroo, par exemple).
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area !== 'local' || !(ch.pending || ch.url || ch.token)) return;
  DK.cfg().then(function (c) { var was = CONF.url + '|' + CONF.token; CONF = c; show(); if (c.url && c.url + '|' + c.token !== was) test(); });
});
// De retour sur cet onglet après s'être connecté : on revérifie.
document.addEventListener('visibilitychange', function () { if (!document.hidden && CONF.url && CONF.token) test(); });

(async function () {
  DK.localize();
  document.title = t('optTitle');
  try { $('ver').textContent = t('version', chrome.runtime.getManifest().version); } catch (e) {}
  CONF = await DK.cfg();
  // Une trouvaille de plus de dix minutes n'est plus d'actualité.
  if (CONF.pending && !(Date.now() - (CONF.pending.at || 0) < 600000)) { DK.forget(['pending']); CONF.pending = null; }
  DK.paint(CONF.accent);
  $('premium').value = CONF.premium || 'auto';
  $('connections').value = CONF.connections ? String(CONF.connections) : '';
  $('dir').value = CONF.dir || '';
  show();
  test();
})();
