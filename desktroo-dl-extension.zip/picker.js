/* Desktroo — © 2026 Mdm-services.fr. Tous droits réservés.
   Logiciel propriétaire, soumis à la licence d'utilisation de Desktroo (LICENSE.md, https://desktroo.fr).
   Copie, modification et redistribution interdites sans accord écrit. Cette mention ne doit pas être retirée. */
/* Desktroo, extension de téléchargements : sélecteur de liens, posé dans la page au clic droit.
   Il liste les liens de la page ; on coche, on envoie. L'envoi lui-même est confié au service d'arrière-plan :
   une page web n'a pas le droit de joindre le NAS. Tout vit dans un « shadow DOM », à l'abri des styles de la page. */
(function () {
  'use strict';
  var t = function (k) { var a = Array.prototype.slice.call(arguments, 1).map(String); try { return chrome.i18n.getMessage(k, a) || k; } catch (e) { return k; } };
  var HOSTS = ['1fichier.com', 'rapidgator.net', 'uptobox.com', 'turbobit.net', 'nitroflare.com', 'ddownload.com', 'mega.nz', 'mediafire.com', 'fikper.com', 'uploaded.net', 'katfile.com', 'gofile.io',
    'pixeldrain.com', 'krakenfiles.com', 'send.cm', '1cloudfile.com', 'dailyuploads.net', 'usersdrive.com', 'file.al', 'frdl.to', 'hitfile.net', 'filespace.com', 'clicknupload.org', 'wupfile.com', 'hexload.com', 'elitefile.net'];
  var FILE = /\.(zip|rar|7z|iso|mkv|mp4|avi|pdf|tar|gz|exe|dmg|apk|epub|flac|mp3|mov|wmv|m4v|bin|img)(\?|#|$)/i;
  var URLS = /https?:\/\/[^\s"'<>\)\]\}]+/g;
  var hostOf = function (u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
  var likely = function (u) { var h = hostOf(u); return HOSTS.some(function (d) { return h === d || h.endsWith('.' + d); }) || FILE.test(u); };

  // Liens de la page : sélection d'abord (toujours cochée), puis liens, attributs usuels et adresses écrites en clair.
  var picked = {}, names = {}, order = [];
  function add(u, on, name) {
    u = String(u || '').trim().replace(/[.,;:!]+$/, '');
    if (!/^https?:\/\//i.test(u) || Object.prototype.hasOwnProperty.call(picked, u)) return;
    picked[u] = !!on; order.push(u);
    // Le texte du lien dans la page aide à le reconnaître (sauf s'il répète l'adresse).
    name = String(name || '').replace(/\s+/g, ' ').trim();
    if (name && name.length <= 120 && !/^https?:\/\//i.test(name)) names[u] = name;
  }
  ((window.getSelection ? String(window.getSelection()) : '').match(URLS) || []).forEach(function (u) { add(u, true); });
  Array.prototype.forEach.call(document.links, function (a) { add(a.href, likely(a.href), a.textContent); });
  Array.prototype.forEach.call(document.querySelectorAll('[data-href],[data-url],[data-link],[data-clipboard-text]'), function (el) {
    ['data-href', 'data-url', 'data-link', 'data-clipboard-text'].forEach(function (at) { var v = el.getAttribute(at); if (v) add(v, likely(v)); });
  });
  ((document.body ? document.body.innerText : '').match(URLS) || []).forEach(function (u) { add(u, likely(u)); });

  var old = document.getElementById('desktroo-picker');
  if (old) old.remove();
  var hostEl = document.createElement('div');
  hostEl.id = 'desktroo-picker';
  hostEl.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;';
  var root = hostEl.attachShadow({ mode: 'closed' });
  var light = window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches;
  var css = ':host{all:initial}*{box-sizing:border-box;margin:0}'
    + '.veil{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(4,9,18,.62);font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;'
    + '--bg:#0f1a2e;--bg2:#16243f;--fg:#e9eef7;--dim:#9db0d0;--line:rgba(255,255,255,.1);--accent:#3ecf8e;--accent2:#55dca0;--ink:#04231a;--bad:#f87171}'
    + '.veil.light{--bg:#f3f7fd;--bg2:#ffffff;--fg:#1a2440;--dim:#5a6b8a;--line:rgba(0,0,0,.12);--accent:#0a8451;--accent2:#0a8451;--ink:#ffffff;--bad:#c9303a}'
    + '.box{display:flex;flex-direction:column;width:min(760px,94vw);max-height:84vh;border-radius:16px;border:1px solid var(--line);background:var(--bg);color:var(--fg);box-shadow:0 24px 60px rgba(0,0,0,.45);overflow:hidden}'
    + 'header{display:flex;align-items:center;gap:12px;padding:16px 18px 14px}'
    + 'header svg{width:26px;height:26px;flex:0 0 auto}h2{flex:1;font-size:17px;font-weight:700;letter-spacing:-.01em;color:var(--fg)}'
    + '.count{font-size:12.5px;color:var(--dim);font-variant-numeric:tabular-nums}'
    + '.tools{display:flex;align-items:center;gap:10px;padding:0 18px 12px}'
    + 'input[type=search]{flex:1;min-width:0;padding:8px 12px;border-radius:9px;border:1px solid var(--line);background:var(--bg2);color:var(--fg);font:inherit;font-size:13px;outline:none}'
    + 'input[type=search]:focus{border-color:var(--accent2)}input[type=search]:focus-visible{outline:none}'
    + '.all{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--dim);cursor:pointer;white-space:nowrap}'
    + '.list{flex:1;overflow:auto;padding:0 10px;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}'
    + '.row{display:flex;align-items:flex-start;gap:10px;padding:8px;border-radius:9px;cursor:pointer}.row:hover{background:rgba(128,140,160,.12)}'
    + '.row span{flex:1;min-width:0;font-size:12.5px;word-break:break-all;color:var(--fg)}.row.dim span{color:var(--dim)}'
    + '.row b{display:block;margin-bottom:1px;font-size:13px;font-weight:600;word-break:normal;overflow-wrap:anywhere}.row i{font-style:normal}.row.named i{font-size:12px;color:var(--dim)}'
    + 'input[type=checkbox]{flex:0 0 auto;width:16px;height:16px;margin-top:1px;accent-color:var(--accent)}'
    + '.none{padding:26px 10px;text-align:center;font-size:13px;color:var(--dim)}'
    + 'footer{display:flex;align-items:center;gap:10px;padding:14px 18px}.msg{flex:1;min-width:0;font-size:12.5px;color:var(--dim)}.msg.bad{color:var(--bad)}.msg.ok{color:var(--accent2)}'
    + 'button{padding:9px 16px;border-radius:9px;border:1px solid var(--line);background:transparent;color:var(--fg);font:inherit;font-size:13px;font-weight:600;cursor:pointer}'
    + 'button:hover{background:rgba(128,140,160,.14)}button.go{border-color:var(--accent);background:var(--accent);color:var(--ink)}button.go:hover{filter:brightness(1.07)}'
    + 'button:disabled{opacity:.55;cursor:default}button:focus-visible,input:focus-visible{outline:2px solid var(--accent2);outline-offset:2px}';
  var logo = '<svg viewBox="4 4 56 56" aria-hidden="true"><rect x="4" y="4" width="56" height="56" rx="15" fill="#12203a"/><circle cx="26" cy="37" r="11" fill="none" stroke="#e9eef7" stroke-width="6"/><rect x="37" y="12" width="6.5" height="38" rx="3.25" fill="#e9eef7"/><circle cx="26" cy="37" r="4.6" fill="#3ecf8e"/></svg>';
  var el = function (tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  var style = document.createElement('style'); style.textContent = css; root.appendChild(style);
  var veil = el('div', 'veil' + (light ? ' light' : '')), box = el('div', 'box');
  box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', t('pickTitle'));
  var head = el('header'); head.innerHTML = logo;
  head.appendChild(el('h2', '', t('pickTitle')));
  var count = el('span', 'count'); head.appendChild(count);
  var tools = el('div', 'tools'), find = el('input');
  find.type = 'search'; find.placeholder = t('pickFilter'); find.setAttribute('aria-label', t('pickFilter'));
  var allLbl = el('label', 'all'), all = el('input'); all.type = 'checkbox';
  allLbl.appendChild(all); allLbl.appendChild(document.createTextNode(t('pickAll')));
  tools.appendChild(find); tools.appendChild(allLbl);
  var list = el('div', 'list'), foot = el('footer'), msg = el('div', 'msg');
  var cancel = el('button', '', t('cancel')), go = el('button', 'go', t('pickSend'));
  foot.appendChild(msg); foot.appendChild(cancel); foot.appendChild(go);
  box.appendChild(head); box.appendChild(tools); box.appendChild(list); box.appendChild(foot);
  veil.appendChild(box); root.appendChild(veil);

  var rows = order.map(function (u) {
    var row = el('label', 'row' + (picked[u] ? '' : ' dim')), cb = el('input'); cb.type = 'checkbox'; cb.checked = picked[u];
    var txt = el('span');
    if (names[u]) { row.classList.add('named'); txt.appendChild(el('b', '', names[u])); }
    txt.appendChild(el('i', '', u));
    row.appendChild(cb); row.appendChild(txt);
    cb.addEventListener('change', function () { picked[u] = cb.checked; row.classList.toggle('dim', !cb.checked); refresh(); });
    list.appendChild(row);
    return { u: u, row: row, cb: cb };
  });
  var none = el('div', 'none', t('pickNone')); list.appendChild(none);
  function shown() { return rows.filter(function (r) { return r.row.style.display !== 'none'; }); }
  function refresh() {
    var n = order.filter(function (u) { return picked[u]; }).length, vis = shown();
    count.textContent = t('pickCount', n, order.length);
    go.disabled = !n;
    none.style.display = vis.length ? 'none' : '';
    none.textContent = order.length ? t('pickNoMatch') : t('pickNone');
    all.checked = vis.length > 0 && vis.every(function (r) { return r.cb.checked; });
  }
  find.addEventListener('input', function () {
    var q = find.value.trim().toLowerCase();
    rows.forEach(function (r) { r.row.style.display = !q || (r.u + ' ' + (names[r.u] || '')).toLowerCase().indexOf(q) >= 0 ? '' : 'none'; });
    refresh();
  });
  // « Tout » ne coche que ce qui est affiché : on peut filtrer puis tout prendre.
  all.addEventListener('change', function () { shown().forEach(function (r) { r.cb.checked = all.checked; picked[r.u] = all.checked; r.row.classList.toggle('dim', !all.checked); }); refresh(); });
  function close() { hostEl.remove(); document.removeEventListener('keydown', onKey, true); }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
  document.addEventListener('keydown', onKey, true);
  cancel.addEventListener('click', close);
  veil.addEventListener('mousedown', function (e) { if (e.target === veil) close(); });
  go.addEventListener('click', function () {
    var urls = order.filter(function (u) { return picked[u]; });
    if (!urls.length) return;
    go.disabled = true; cancel.disabled = true; msg.className = 'msg'; msg.textContent = t('pickSending');
    chrome.runtime.sendMessage({ type: 'dk-send', urls: urls }, function (res) {
      var err = chrome.runtime.lastError;
      res = res || { ok: false, text: (err && err.message) || t('errUnknown') };
      msg.textContent = res.text || '';
      if (res.ok && res.added) { msg.className = 'msg ok'; cancel.disabled = false; cancel.textContent = t('close'); setTimeout(close, 1600); return; }
      msg.className = 'msg bad'; go.disabled = false; cancel.disabled = false;
      // Réglages à faire, adresse à autoriser ou jeton à revoir : l'extension ouvre sa page de réglages.
      if (res.kind === 'setup' || res.kind === 'perm' || res.kind === 'token') chrome.runtime.sendMessage({ type: 'dk-options' });
    });
  });
  (document.body || document.documentElement).appendChild(hostEl);
  refresh();
  find.focus();
})();
