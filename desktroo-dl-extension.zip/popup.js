/* Desktroo, extension de téléchargements : fenêtre de l'icône. */
'use strict';
var $ = function (id) { return document.getElementById(id); };
var t = DK.t, CONF = null, timer = null;
var ICONS = {
  pause: '<path d="M9 5v14M15 5v14"/>', play: '<path d="M7 5l12 7-12 7z"/>', stop: '<path d="M6 6l12 12M18 6L6 18"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3"/>'
};
var STATES = { downloading: ['stDownloading', 'ok'], queued: ['stQueued', ''], paused: ['stPaused', 'warn'], extracting: ['stExtracting', 'info'], done: ['stDone', 'ok'], error: ['stError', 'bad'], canceled: ['stCanceled', ''] };

function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function size(n) {
  n = Number(n) || 0;
  var u = t('units').split(','), i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i ? n.toFixed(n < 10 ? 1 : 0) : String(Math.round(n))).replace('.', t('decimal')) + ' ' + u[i];
}
function eta(s) {
  s = Math.round(Number(s) || 0);
  if (s <= 0) return '';
  if (s < 60) return t('etaSec', s);
  if (s < 3600) return t('etaMin', Math.round(s / 60));
  return t('etaHour', Math.floor(s / 3600), Math.round((s % 3600) / 60));
}
function note(text, kind) { var n = $('note'); n.hidden = !text; n.className = 'note' + (kind ? ' ' + kind : ''); n.textContent = text || ''; }

// Un écran de situation : titre, phrase, bouton(s).
function state(title, text, buttons) {
  var s = $('state');
  s.textContent = '';
  s.appendChild(el('h2', '', title));
  if (text) { var p = el('p'); if (typeof text === 'string') p.textContent = text; else p.appendChild(text); s.appendChild(p); }
  (buttons || []).forEach(function (b) { var x = el('button', 'btn' + (b.main ? ' main' : ''), b.label); x.addEventListener('click', b.run); s.appendChild(x); });
  s.hidden = false; $('list').hidden = true; $('foot').hidden = true;
}
function openOptions() { chrome.runtime.openOptionsPage(); window.close(); }

function render(items) {
  var list = $('list');
  $('add').hidden = false; $('foot').hidden = false;
  // Le compteur de l'icône suit ce que la fenêtre vient de lire.
  try { var act = items.filter(DK.isActive).length; chrome.action.setBadgeText({ text: act ? String(act) : '' }); } catch (e) {}
  if (!items.length) {
    state(t('emptyTitle'), t('emptyText'));
    $('foot').hidden = false;
    return;
  }
  $('state').hidden = true; list.hidden = false;
  list.textContent = '';
  items.forEach(function (it) {
    var st = STATES[it.status] || [it.status, ''], tot = Number(it.total) || 0, got = Number(it.downloaded) || 0;
    var pct = tot > 0 ? Math.min(100, Math.round(got / tot * 100)) : (it.status === 'done' ? 100 : 0);
    var row = el('div', 'it'), top = el('div', 'it-top'), acts = el('div', 'it-acts');
    var name = el('div', 'it-name', it.filename || t('unnamed')); name.title = it.filename || '';
    var act = function (action, icon, label) {
      var b = el('button', 'icon-btn'); b.title = label; b.setAttribute('aria-label', label);
      b.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS[icon] + '</svg>';
      b.addEventListener('click', function () { b.disabled = true; DK.call('/downloads/' + action, { id: it.id }, CONF).then(refresh); });
      acts.appendChild(b);
    };
    if (it.status === 'downloading' || it.status === 'queued') act('pause', 'pause', t('actPause'));
    if (it.status === 'paused') act('resume', 'play', t('actResume'));
    if (it.status === 'downloading' || it.status === 'queued' || it.status === 'paused') act('cancel', 'stop', t('actCancel'));
    if (it.status === 'done' || it.status === 'error' || it.status === 'canceled') act('remove', 'trash', t('actRemove'));
    top.appendChild(name); top.appendChild(acts); row.appendChild(top);
    var bar = el('div', 'bar' + (it.status === 'paused' ? ' paused' : it.status === 'error' ? ' bad' : (it.status === 'queued' || it.status === 'canceled') ? ' idle' : ''));
    var fill = el('i'); fill.style.width = pct + '%'; bar.appendChild(fill); row.appendChild(bar);
    var meta = el('div', 'it-meta'), stEl = el('span', 'it-state'), dot = el('span', 'dot' + (st[1] ? ' ' + st[1] : ''));
    stEl.appendChild(dot); stEl.appendChild(document.createTextNode(t(st[0]) + (it.status === 'downloading' && tot > 0 ? ' ' + t('percent', pct) : '')));
    meta.appendChild(stEl);
    meta.appendChild(el('span', 'grow', tot > 0 ? (got > 0 && got < tot ? t('sizeOf', size(got), size(tot)) : size(tot)) : (got > 0 ? size(got) : '')));
    if (it.status === 'downloading') {
      var sp = Number(it.speed) > 0 ? t('speed', size(it.speed)) : '', e = eta(it.eta);
      meta.appendChild(el('span', '', [sp, e].filter(Boolean).join(', ')));
    }
    row.appendChild(meta);
    if (it.error) { var er = el('div', 'it-err', String(it.error)); er.title = String(it.error); row.appendChild(er); }
    list.appendChild(row);
  });
}

async function refresh() {
  var res = await DK.call('/downloads/list', null, CONF);
  if (res.ok) { render(res.data.downloads || []); return; }
  clearInterval(timer); timer = null;
  $('add').hidden = true;
  var h = DK.host(CONF.url);
  if (res.kind === 'perm') state(t('permTitle'), t('errPerm', h), [{ label: t('permButton'), main: true, run: openOptions }]);
  else if (res.kind === 'auth') state(t('authTitle'), t('errAuth'), [{ label: t('authButton'), main: true, run: function () { chrome.tabs.create({ url: res.login || DK.origin(CONF.url) + '/' }); window.close(); } }]);
  else if (res.kind === 'token') state(t('tokenTitle'), t('errToken'), [{ label: t('tokenButton'), main: true, run: openOptions }]);
  else if (res.kind === 'network') state(t('networkTitle'), t('errNetwork', h), [{ label: t('retry'), main: true, run: start }]);
  else state(t('apiTitle'), DK.explain(res, CONF), [{ label: t('retry'), main: true, run: start }]);
}
function start() { clearInterval(timer); refresh(); timer = setInterval(refresh, 2000); }

// Rien n'est encore réglé : si l'onglet affiché est un Desktroo, on propose de s'y relier en un clic.
async function setup() {
  $('add').hidden = true;
  var found = null;
  try {
    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].id != null) {
      // L'ouverture de cette fenêtre autorise l'extension sur l'onglet affiché, et seulement lui (activeTab).
      var out = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: function () {
        var isDesktroo = document.title === 'Desktroo' && !!document.getElementById('taskbar') && !!document.getElementById('desktop');
        var token = ''; try { token = localStorage.getItem('fileops_token') || ''; } catch (e) {}
        return isDesktroo ? { origin: location.origin, host: location.host, token: token } : null;
      } });
      found = out && out[0] && out[0].result;
    }
  } catch (e) {}
  if (found && found.token) {
    var p = document.createDocumentFragment();
    p.appendChild(document.createTextNode(t('setupFound') + ' '));
    p.appendChild(el('span', 'host', found.host));
    state(t('setupTitle'), p, [{ label: t('setupConnect'), main: true, run: function () {
      DK.save({ pending: { url: found.origin + '/fileops', token: found.token, at: Date.now() } }).then(openOptions);
    } }]);
  } else if (found) state(t('setupTitle'), t('setupLogin'), [{ label: t('setupManual'), run: openOptions }]);
  else state(t('setupTitle'), t('setupHow'), [{ label: t('setupManual'), run: openOptions }]);
}

$('add').addEventListener('submit', function (e) {
  e.preventDefault();
  var u = $('add-url').value.trim();
  if (!/^https?:\/\/\S+$/i.test(u)) { note(t('addInvalid'), 'bad'); return; }
  $('add-go').disabled = true; note(t('pickSending'));
  chrome.runtime.sendMessage({ type: 'dk-send', urls: [u] }, function (res) {
    $('add-go').disabled = false;
    res = res || { ok: false, text: t('errUnknown') };
    note(res.text, res.ok && res.added ? 'ok' : 'bad');
    if (res.ok && res.added) { $('add-url').value = ''; refresh(); }
  });
});
$('settings').addEventListener('click', openOptions);
$('clear').addEventListener('click', function () { DK.call('/downloads/clear', {}, CONF).then(refresh); });
$('open').addEventListener('click', function () { chrome.tabs.create({ url: DK.origin(CONF.url) + '/?app=downloads' }); window.close(); });
window.addEventListener('unload', function () { clearInterval(timer); });

(async function () {
  DK.localize();
  CONF = await DK.cfg();
  DK.paint(CONF.accent);
  if (!CONF.url || !CONF.token) { setup(); return; }
  $('what').textContent = DK.host(CONF.url);
  start();
  DK.refreshAccent(CONF).then(function (a) { if (a) DK.paint(a); });
})();
